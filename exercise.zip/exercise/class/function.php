<?php
$db = new pdo("mysql:host=localhost;dbname=nizz","root","");
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	// echo "Hello from db";
	} catch (PDOException $e) {
	echo "Connection error: ". $e->getMessage();
}

$data = array(
	':fname' 	=> $_POST['fname'],
	':lname' 	=> $_POST['lname'],
	':email' 	=> $_POST['email'],
	':address' 	=> $_POST['address'],
	':city' 	=> $_POST['city'],
	':dob' 		=> $_POST['dob'],
	':zip' 		=> $_POST['zip'],
	':radio' 	=> $_POST['radio'],
	':status' 	=> $_POST['status'],
);

$sql = "INSERT INTO registration(first_name,last_name,email,password,address,city,date_of_birth,zip_code,genger,status) VALUES(:fname,:lname,:email,:password,:address,:city,:dob,:zip,:genger,:status)";

 $stmt = $db->prepare($sql);
 $stmt->execute($data);
/*
'fname': fname,
'lname': lname,
'email': email,
'password': password,
'address': address,
'city': city,
'dob': dob,
'zip': zip,
'radio': radio,
'status': status*/

?>

  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script type="text/javascript">

		$("#form").submit(function(event){
			// event.preventDefault();
			var fname 	= document.getElementById("fname").value;
			var lname 	= document.getElementById("lname").value;
			var email 	= document.getElementById("email").value;
			var password= document.getElementById("password").value;
			var address = document.getElementById("address").value;
			var city 	= document.getElementById("city").value;
			var dob 	= document.getElementById("date-of-birth").value;
			var zip 	= document.getElementById("zip").value;
			var radio 	= $('input[name=gender]:checked').val();
			var status 	= $('input[type="checkbox"]').is(':checked') ? 1 : 0;
			// console.log(fname+lname+email+password+address+city+dob);
			// if (validate()==true) {
				$.ajax({
					url: 'function.php',
					method: 'POST',
					dataType: 'JSON',
					data: {
							'fname': fname,
							'lname': lname,
							'email': email,
							'password': password,
							'address': address,
							'city': city,
							'dob': dob,
							'zip': zip,
							'radio': radio,
							'status': status
						}
					/*success: function(data){
						console.log($data);
						// console.log('submited successfully');
					}
					error: function(data){
						console.log('some error occur');
					}*/
				});

			// }
		});

	/*function validate(data){
		if (isNaN(data) || data.length >25 || data.length<3) {
			var error = "Input must be 3 to 25 Letter";
			$("#message").show();
			document.getElementById("message").innerHTML = error;

		}
			return false;
	} */
	
</script>
  </body>
</html>
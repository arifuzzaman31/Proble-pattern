<?php

try {
	$db = new pdo("mysql:host=localhost;dbname=nizz","root","");
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	// echo "Hello from db";
	} catch (PDOException $e) {
	echo "Connection error: ". $e->getMessage();
}


?>
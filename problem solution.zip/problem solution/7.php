<?php

//7. program to construct the following pattern, using a nested for loop

for ($i=1; $i <= 6; $i++) { 
	for ($j=1; ($j>3) ?  $j<6-$i : $j<$i+1; $j++) {
		echo '* ';
	}
		echo '<br>';
}
		

?>
<?php include('top.php'); ?>

<div class="container">
  		<div class="card mt-4">
  			<div class="card-header d-flex justify-content-between">
  				<h2>Person</h2>
  				<button class="btn btn-primary float-right" id="add-data">Add</button>
  			</div>
  			<div class="card-body">
  				  
  			</div>
  		</div>
  </div>


<!-- Large modal -->
<div class="modal fade bd-example-modal-lg" id="modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-body">
      	
      </div>
    </div>
  </div>
</div>
<?php include('bottom.php'); ?>
    


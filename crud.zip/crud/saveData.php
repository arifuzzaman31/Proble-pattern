<?php
include('database.php');
// echo "<pre>";
$formData 	= $_POST['data'];
$fname		= $formData['first_name'];
$lname 		= $formData['last_name'];
$email 		= $formData['email'];
$dob 		= $formData['dob'];
$contact 	= $formData['contact'];
$city 		= $formData['city'];
$state 		= $formData['state'];
$zip_code 	= $formData['zip'];
$gender 	= $formData['gender'];
$status 	= $formData['status'];
// print_r($formData);

$sql = " INSERT INTO registration (first_name,last_name,email,dob,contact,city,state,zip_code,gender,status) VALUES($fname,$lname,$email,$dob,$contact,$city,$state,$zip_code,$gender,$status) ";

$result = mysqli_query($con, $sql);

?>